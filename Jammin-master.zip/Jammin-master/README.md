# Jammin

Jammin merupakan Aplikasi Android yang Berbasis Java.
Aplikasi ini merupakan Aplikasi yang dapat memutar Lagu atau Audio yang disediakan oleh Sistem.
Kita dapat masuk Sebagai User atau Creator.

Adapun Fitur pada User yaitu:
- Home : Pada bagian Home, terdapat:
1. Tampilan Selamat Datang berdasarkan Username dari User.
2. Search Bar untuk Mencari Lagu yang ada. 
3. List Pilihan Lagu yang disediakan oleh Sistem.
4. Rekomendasi Lagu yang disediakan oleh Sistem.

- Profile : Pada bagian Profile, terdapat:
1. Tampilan yang menunjukkan Profile Picture yang dapat ditekan untuk memilih Image.
2. Tombol Upload Picture dan Delete Picture.
3. Username dari User.
4. Tombol Sign Out.

Adapun Fitur pada Creator yaitu:
- Home : Pada bagian Home, terdapat: 
1. Tampilan Selamat Datang berdasarkan Username dari Creator.
2. Image berdasarkan Status apakah Creator sudah pernah Upload Lagu atau belum.
3. Select Song untuk Memilih Song yang akan Diupload.
4. Button Upload Song untuk mengirimkan Song ke Database.
5. Button Delete Song untuk menghapus Song yang terdapat pada Database.

- Profile : Pada bagian Profile, terdapat: 
1. Tampilan yang menunjukkan Profile Picture yang dapat ditekan untuk memilih Image.
2. Tombol Upload Picture dan Delete Picture.
3. Username dari Creator.
4. Tombol Sign Out.
