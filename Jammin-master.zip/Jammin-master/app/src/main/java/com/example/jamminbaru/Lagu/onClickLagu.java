package com.example.jamminbaru.Lagu;

public interface onClickLagu {
    void onItemClick(lagumodel lagu);
}
